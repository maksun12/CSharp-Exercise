﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;


namespace WordCount
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, int> wordDictionary = new Dictionary<string, int>();

            string input = File.ReadAllText("../../../words.txt");

            string[] words = input.Split(new string[] { Environment.NewLine }, StringSplitOptions.None);

            String pattern = @"[a-zA-Z']+";
            Regex regex = new Regex(pattern);

            using (var reader = new StreamReader("../../../text.txt"))
            {
                string currentSentcenceWord = reader.ReadLine();

                while (currentSentcenceWord != null)
                {
                    foreach (Match match in regex.Matches(currentSentcenceWord))
                    {
                        for (int i = 0; i < words.Length; i++)
                        {

                            if (match.Value.ToLower() == words[i] && !(wordDictionary.ContainsKey(words[i])))
                            {
                                wordDictionary.Add(words[i], 1);
                            }
                            else if (match.Value.ToLower() == words[i])
                            {
                                wordDictionary[words[i]]++;
                            }
                        }
                    }
                    currentSentcenceWord = reader.ReadLine();
                }

                using (StreamWriter writer = new StreamWriter("../../../actualResults.txt"))
                {
                    foreach (var item in wordDictionary)
                    {
                        writer.WriteLine("{0} - {1}", item.Key, item.Value);

                    }
                }

                using (StreamWriter writer = new StreamWriter("../../../expectedResult.txt"))
                {
                    foreach (var item in wordDictionary.OrderByDescending(key => key.Value))
                    {
                        writer.WriteLine("{0} - {1}", item.Key, item.Value);
                        Console.WriteLine("{0} - {1}", item.Key, item.Value);
                    }
                }
            }
        }
    }
}
﻿using System;
using System.IO.Compression;

namespace ZipAandExtract
{
    class Program
    {
        static void Main(string[] args)
        {
            ZipFile.CreateFromDirectory(@"C:\Users\maksun12\Desktop\Stream", @"C:\Users\maksun12\Desktop\StreamZip\MyZip.zip");
            ZipFile.ExtractToDirectory(@"C:\Users\maksun12\Desktop\StreamZip\MyZip.zip" , @"C:\Users\maksun12\Desktop\ZipResult");
        }
    }
}

﻿using System;
using System.IO;
using System.Linq;

namespace LineNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] lines = File.ReadAllLines("../../../text.txt");

            string[] newLines = new string[lines.Length];

            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i];
                int countOfLetter = CountOfLetters(line);
                int countOfMarks = CountoOfPunctuationMarks(line);

                newLines[i] = $"Line {i + 1}: {lines[i]}({countOfLetter})({countOfMarks})";
            }
            for (int i = 0; i < newLines.Length; i++)
            {
                Console.WriteLine(newLines[i]);
            }
        }
        static int CountOfLetters(string line)
        {
            int counter = 0;

            for (int i = 0; i < line.Length; i++)
            {
                char currentSymbol = line[i];
                if (Char.IsLetter(currentSymbol))
                    
                {
                    counter++;
                }
            }
            return counter;
        }
        static int CountoOfPunctuationMarks(string line)
        {
            char[] punctuationMarks = {'-',',','.','!','?','\'',':',';'};

            int counter = 0;

            for (int i = 0; i < line.Length; i++)
            {
                char currentSymbol = line[i];
                if (punctuationMarks.Contains(currentSymbol))
                {
                    counter++;
                }
                
            }
            return counter;
        }
        
    }
}

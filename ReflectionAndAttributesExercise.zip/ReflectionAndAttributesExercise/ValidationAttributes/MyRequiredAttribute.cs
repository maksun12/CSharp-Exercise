﻿using System;

namespace ValidationAttributes
{
    public class MyRequiredAttribute : MyValidationAttributes
    {
        public override bool IsValid(object obj)
        {
            return obj!=null;
        }
    }
}
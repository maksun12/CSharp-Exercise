﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AutoMapper;
using CarDealer.Data;
using CarDealer.DTO;
using CarDealer.Models;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var db = new CarDealerContext();
            db.Database.EnsureDeleted(); 
            db.Database.EnsureCreated();

            //Ex1
            //var json = File.ReadAllText("../../../Datasets/suppliers.json");
            //Console.WriteLine(ImportSuppliers(db,json));

            //Ex2
            //var json = File.ReadAllText("../../../Datasets/suppliers.json");
            //Console.WriteLine(ImportParts(db, json));

            //Ex3
            //var json = File.ReadAllText("../../../Datasets/cars.json");
            //Console.WriteLine(ImportCars(db, json));

            //Ex4
            //var json = File.ReadAllText("../../../Datasets/customers.json");
            //Console.WriteLine(ImportCustomers(db, json));

            //Ex5
            //var json = File.ReadAllText("../../../Datasets/sales.json");
            //Console.WriteLine(ImportSales(db, json));
        }

        //Ex1
        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
            var supplierDtos = JsonConvert.DeserializeObject<IEnumerable<ImportSuppliersInputModel>>(inputJson);

            var suppliers = supplierDtos.Select(x => new Supplier
            {
                Name = x.Name,
                IsImporter = x.IsImporter
            })
                .ToList();

            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Count}.";
        }

        //Ex2
        public static string ImportParts(CarDealerContext context, string inputJson)
        {
            var suppliedIds = context.Suppliers.Select(x => x.Id).ToArray();

            var partsDtos = JsonConvert
                .DeserializeObject<IEnumerable<ImportPartsInputModel>>(inputJson)
                .Where(s => suppliedIds.Contains(s.SupplierId))
                .ToList();

            var parts = partsDtos.Select(x => new Part
            {
                Name = x.Name,
                Price=x.Price,
                Quantity=x.Quantity,
                SupplierId=x.SupplierId
            })
                .ToList();

            context.Parts.AddRange(parts);
            context.SaveChanges();

            return $"Successfully imported {parts.Count}.";
        }

        //Ex3
        public static string ImportCars(CarDealerContext context, string inputJson)
        {
            var carsDtos = JsonConvert.DeserializeObject<IEnumerable<ImportCarsInputModel>>(inputJson);

            var listOfCar = new List<Car>();

            foreach (var car in carsDtos)
            {
                var currCar = new Car
                {
                    Make = car.Make,
                    Model = car.Model,
                    TravelledDistance = car.TravelledDistance,
                };
                foreach (var partsId in car?.PartsId.Distinct())
                {
                    currCar.PartCars.Add(new PartCar
                    {
                        PartId = partsId
                    });
                }
                listOfCar.Add(currCar);
            }


            context.Cars.AddRange(listOfCar);
            context.SaveChanges();

            return $"Successfully imported {listOfCar.Count}.";

        }


        //Ex4
        public static string ImportCustomers(CarDealerContext context, string inputJson)
        {
            var customerDtos = JsonConvert.DeserializeObject<IEnumerable<ImportCustomersInputModel>>(inputJson);

            var customers = customerDtos.Select(x => new Customer
            {
                Name = x.Name,
                BirthDate = x.BirthDate,
                IsYoungDriver=x.IsYoungDriver
               
            })
                .ToList();

            context.Customers.AddRange(customers);
            context.SaveChanges();

            return $"Successfully imported {customers.Count}.";
        }

        //Ex5
        public static string ImportSales(CarDealerContext context, string inputJson)
        {
            var saleDtos = JsonConvert.DeserializeObject<IEnumerable<ImportSalesInputModel>>(inputJson);

            var sales = saleDtos.Select(x => new Sale
            {
              CarId=x.CarId,
              CustomerId=x.CustomerId,
              Discount=x.Discount

            })
                .ToList();

            context.Sales.AddRange(sales);
            context.SaveChanges();

            return $"Successfully imported {sales.Count}.";
        }
    }
}
﻿using Bakery.Core.Contracts;
using Bakery.Models.BakedFoods;
using Bakery.Models.BakedFoods.Contracts;
using Bakery.Models.Drinks;
using Bakery.Models.Drinks.Contracts;
using Bakery.Models.Tables;
using Bakery.Models.Tables.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace Bakery.Core
{
   
    public class Controller : IController
    {
        private readonly ICollection<Table> tables;
        
        private readonly ICollection<BakedFood> bakedFoods;
        private readonly ICollection<Drink> drinks;

        public Controller()
        {
            tables = new List<Table>();
            bakedFoods = new List<BakedFood>();
            drinks = new List<Drink>();
        }
        public string AddDrink(string type, string name, int portion, string brand)
        {
            Drink drink=null;
           
            if (type=="Tea")
            {
                drink = new Tea(name, portion, brand);
            }
            if (type == "Water")
            {
                drink = new Water(name, portion, brand);
            }
            drinks.Add(drink);
            return $"Added {name} ({brand}) to the drink menu";
        }

        public string AddFood(string type, string name, decimal price)
        {
            BakedFood bakedfood=null;

            if (type=="Bread")
            {
                bakedfood = new Bread(name, price);
            }
            else if (type == "Cake")
            {
                bakedfood = new Cake(name, price);
            }
            bakedFoods.Add(bakedfood);
            return $"Added {name} ({type}) to the menu";
        }

        public string AddTable(string type, int tableNumber, int capacity)
        {
            Table table=null;
            if (type=="InsideTable")
            {
                table = new InsideTable(tableNumber, capacity);
            }
           
           else if (type == "OutsideTable")
            {
                table = new OutsideTable(tableNumber, capacity);
                    
            }
            tables.Add(table);
            return $"Added table number {tableNumber} in the bakery";
        }

        public string GetFreeTablesInfo()
        {
            StringBuilder stringBuilder = new StringBuilder();
            foreach (var table in tables)
            {
                stringBuilder.AppendLine(table.GetFreeTableInfo());
         
            }
            return stringBuilder.ToString().TrimEnd();


        }

        public string GetTotalIncome()
        {
            StringBuilder stringBuilder = new StringBuilder();
            foreach (var table in tables)
            {
                stringBuilder.AppendLine($"Total income: {table.Price:f2}lv");

            }
            return stringBuilder.ToString().TrimEnd();
        }

        public string LeaveTable(int tableNumber)
        {
            StringBuilder stringBuilder = new StringBuilder();
            foreach (var table in tables)
            {
                if (table.IsReserved)
                {
                    stringBuilder.AppendLine($"No available table for {tableNumber}");
                }
                else
                {
                    stringBuilder.AppendLine($"Table {table.TableNumber} has been reserved for {tableNumber} people");
                }
                

            }
            return stringBuilder.ToString().TrimEnd();

        }

        public string OrderDrink(int tableNumber, string drinkName, string drinkBrand)
        {
            StringBuilder stringBuilder = new StringBuilder();
            foreach (var table in tables)
            {
                if (table.TableNumber==null)
                {
                    stringBuilder.AppendLine($"Could not find table {tableNumber}");
                }
               
                else
                {
                    stringBuilder= stringBuilder.AppendLine($"Table {tableNumber} ordered {drinkName} {drinkBrand}");
                }

            }
            return stringBuilder.ToString().TrimEnd();
        }

        public string OrderFood(int tableNumber, string foodName)
        {
            StringBuilder stringBuilder = new StringBuilder();
            foreach (var table in tables)
            {

                if (table.TableNumber == null)
                {
                    stringBuilder.AppendLine($"Could not find table {tableNumber}");
                }
                else
                {
                    stringBuilder = stringBuilder.AppendLine($"Table {tableNumber} ordered {foodName}");
                }
             
                

            }
            return stringBuilder.ToString().TrimEnd();
        }

        public string ReserveTable(int numberOfPeople)
        {
            StringBuilder stringBuilder = new StringBuilder();
            foreach (var table in tables)
            {
                if (table.TableNumber>0)
                {
                    stringBuilder.AppendLine($"No available table for {table.TableNumber}");
                }
                else
                {
                    stringBuilder.AppendLine($"Table {table.TableNumber} has been reserved for {table.TableNumber} people");
                }


            }
            return stringBuilder.ToString();

        }
    }
}

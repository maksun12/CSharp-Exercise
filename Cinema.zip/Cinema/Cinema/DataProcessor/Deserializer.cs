﻿namespace Cinema.DataProcessor
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Globalization;
    using System.Text;
    using Cinema.Data.Models;
    using Cinema.Data.Models.Enums;
    using Cinema.DataProcessor.ImportDto;
    using Data;
    using Newtonsoft.Json;
    using SoftJail.DataProcessor;

    public class Deserializer
    {
        private const string ErrorMessage = "Invalid data!";

        private const string SuccessfulImportMovie
            = "Successfully imported {0} with genre {1} and rating {2}!";

        private const string SuccessfulImportProjection
            = "Successfully imported projection {0} on {1}!";

        private const string SuccessfulImportCustomerTicket
            = "Successfully imported customer {0} {1} with bought tickets: {2}!";

        public static string ImportMovies(CinemaContext context, string jsonString)
        {
            var sb = new StringBuilder();
            var movies = new List<Movie>();

            var movieCells = JsonConvert.DeserializeObject<IEnumerable<ImportMovieDto>>(jsonString);

            foreach (var movieCurr in movieCells)
            {
                if (!IsValid(movieCurr))
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }

                var duration = TimeSpan.ParseExact(movieCurr.Duration, "c", System.Globalization.CultureInfo.InvariantCulture);

                var movie = new Movie
                {
                    Title = movieCurr.Title,
                    Genre = Enum.Parse<Genre>(movieCurr.Genre),
                    Duration = duration,
                    Rating = movieCurr.Rating,
                    Director = movieCurr.Director

                };
                movies.Add(movie);
                sb.AppendLine($"Successfully imported {movie.Title} with genre {movie.Genre} and rating {movie.Rating:F2}!");
            }
            context.Movies.AddRange(movies);
            context.SaveChanges();

            return sb.ToString().TrimEnd();
        }

        public static string ImportProjections(CinemaContext context, string xmlString)
        {
            var sb = new StringBuilder();
            var validProjection = new List<Projection>();

            var projectionDtos = XmlConverter
                .Deserializer<ImportProjectionDto>(xmlString, "Projections");

            foreach (var projectionCurr in projectionDtos)
            {
                if (!IsValid(projectionCurr))
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }

                var datetime = DateTime.ParseExact(
                  projectionCurr.DateTime,
                  "yyyy-MM-dd HH:mm:ss",
                  CultureInfo.InvariantCulture);

                var projection = new Projection
                {
                 MovieId=projectionCurr.MovieId,
                 DateTime=datetime
                };

                validProjection.Add(projection);

                sb.AppendLine($"Successfully imported projection {projection.MovieId} on {projection.DateTime:MM/dd/yyyy}!");
            }

            context.Projections.AddRange(validProjection);
            context.SaveChanges();

            return sb.ToString().TrimEnd();

        }

        public static string ImportCustomerTickets(CinemaContext context, string xmlString)
        {
            throw new NotImplementedException();
        }
        private static bool IsValid(object obj)
        {
            var validationContext = new System.ComponentModel.DataAnnotations.ValidationContext(obj);
            var validationResult = new List<ValidationResult>();

            bool isValid = Validator.TryValidateObject(obj, validationContext, validationResult, true);
            return isValid;
        }
    }
}
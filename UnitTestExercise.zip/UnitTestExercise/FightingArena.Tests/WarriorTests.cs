using NUnit.Framework;
using System;
using FightingArena;

public class WarriorTests
{
    [SetUp]
    public void Setup()
    {
    }

    [Test]
    [TestCase("Ivan", 10, 10)]
    [TestCase("Petyr", 120, 130)]
    [TestCase("Mitko", 1220, 1340)]
    public void WarriorConstructorShouldSetDataProperly(string name, int dmg, int hp)
    {
        Warrior warrior = new Warrior(name, dmg, hp);

        Assert.AreEqual(name, warrior.Name);
        Assert.AreEqual(dmg, warrior.Damage);
        Assert.AreEqual(hp, warrior.HP);
    }
    [Test]
    [TestCase("", 120, 130)]
    [TestCase(" ", 120, 130)]
    [TestCase(null, 1220, 1340)]
    public void WarriorConstructorShouldThrowExceptionIfInvalidNameIsPassed(string name, int dmg, int hp)
    {
        Assert.Throws<ArgumentException>(() => new Warrior(name, dmg, hp));
    }

    [Test]
    [TestCase("Ivan", 0, 10)]
    [TestCase("Petyr", -1, 130)]
    public void WarriorConstructorShouldThrowExceptionIfInvalidDamageIsPassed(string name, int dmg, int hp)
    {
        Assert.Throws<ArgumentException>(() => new Warrior(name, dmg, hp));
    }
    [Test]
    [TestCase("Ivan", 20, -1)]
    public void WarriorConstructorShouldThrowExceptionIfInvalidHPIsPassed(string name, int dmg, int hp)
    {
        Assert.Throws<ArgumentException>(() => new Warrior(name, dmg, hp));
    }

    [Test]
    [TestCase("Ivan", 10, 10, "Mitko", 10, 10)]
    [TestCase("Ivan", 10, 100, "Mitko", 10, 10)]
    [TestCase("Ivan", 10, 50, "Mitko", 100, 50)]
    public void WarriorAttackOperationShouldThrowInvalidOperaionExceptionIfHpIsInvalid(string fighterName, int fighterDmg, int fighterHp, string defenderName, int defenderDmg, int defenderHp)
    {
        var fighter = new Warrior(fighterName, fighterDmg, fighterHp);
        var defender = new Warrior(defenderName, defenderDmg, defenderHp);

        Assert.Throws<InvalidOperationException>(() => fighter.Attack(defender));
    }

    [Test]
    [TestCase("Ivan", 10, 50, "Mitko", 10, 50, 40, 40)]
    [TestCase("Ivan", 50, 100, "Mitko", 10, 40, 90, 0)]
    public void WarriorAttackOperationShouldDecreaseHp(string fighterName, int fighterDmg, int fighterHp, string defenderName, int defenderDmg, int defenderHp, int expectedFighterHpResult, int expectedDefenderHpResult)
    {
        var fighter = new Warrior(fighterName, fighterDmg, fighterHp);
        var defender = new Warrior(defenderName, defenderDmg, defenderHp);
        fighter.Attack(defender);

        Assert.AreEqual(fighter.HP, expectedFighterHpResult);
        Assert.AreEqual(defender.HP, expectedDefenderHpResult);

    }
}
﻿using NUnit.Framework;
using System;
using System.Linq;
using FightingArena;

 public class ArenaTests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void ConstructorShouldInitializeDepedentValues()
        {
            Arena arena = new Arena();
            Assert.IsNotNull(arena.Warriors);
        }
        
        [Test]
        [TestCase("Ivan", 10, 10)]
        public void EnrollShouldThrowExceptionIfWarriorExists(string name,int dmg,int hp)
        {
            Arena arena = new Arena();
            Warrior warrior = new Warrior(name,dmg,hp);
            arena.Enroll(warrior);

            Assert.Throws<InvalidOperationException>(() => arena.Enroll(warrior));
        }

        [Test]
        [TestCase("Ivan", 10, 10,1,"Ivan")]
    [TestCase("Mitko", 10, 10, 1, "Mitko")]
    public void EnrollShouldAddWarriorToCollection(string name, int dmg, int hp, int expectedResult, string expectedNameResult)
        {
            Arena arena = new Arena();
            Warrior warrior = new Warrior(name, dmg, hp);
            arena.Enroll(warrior);

            var isAny = arena.Warriors.Any(x => x.Name == expectedNameResult);
            Assert.AreEqual(expectedResult, arena.Count);
            Assert.IsTrue(isAny);
        }
        [Test]
        [TestCase("Ivan", 10, 10, 1, "Mitko")]
        public void FightShouldThrowExceptionIfWarriorDoesntExist(string name, int dmg, int hp, int expectedResult, string fakeName)
        {
            Arena arena = new Arena();
           
            Assert.Throws<InvalidOperationException>(() => arena.Fight(name, fakeName));
           
            Warrior warrior = new Warrior(name, dmg, hp);
           
            arena.Enroll(warrior);

            Assert.Throws<InvalidOperationException>(()=>arena.Fight(name,fakeName));
        }

    [Test]
    [TestCase("Ivan", 10, 50, "Mitko", 10, 50,"Ivan","Mitko",40,40)]
    public void FightShouldWorkAsExpected(string fighterName, int fighterDmg, int fighterHp, string defenderName, int defenderDmg, int defenderHp,string expectedFighterNameResult,string expectedDefenderNameResult, int expectedFighterResult, int expectedDefenderResult)
    {
       Arena arena = new Arena();
        Warrior fighter = new Warrior(fighterName, fighterDmg, fighterHp);
        Warrior defender = new Warrior(defenderName, defenderDmg, defenderHp);
        
        arena.Enroll(fighter);
        arena.Enroll(defender);
        arena.Fight(fighterName, defenderName);
        
        var fighterHPesult = arena.Warriors.FirstOrDefault(x => x.Name == expectedFighterNameResult).HP;
        var defenderHPResult = arena.Warriors.FirstOrDefault(x => x.Name == expectedDefenderNameResult).HP;

        Assert.AreEqual(fighterHPesult, expectedFighterResult);
        Assert.AreEqual(defenderHPResult, expectedDefenderResult);
    }

}


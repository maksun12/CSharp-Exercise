using CarManager;
using NUnit.Framework;
using System;


public class CarTests
{
    [SetUp]
    public void Setup()
    {
    }

    [Test]
    [TestCase("Bmw", "320", 20, 200)]
    public void CarConstructorShouldSetAllDataCorrectly(string make, string model, double fuelConsumption, double fuelCapacity)
    {
        //Arrange
        Car car = new Car(make: make, model: model, fuelConsumption: fuelConsumption, fuelCapacity: fuelCapacity);

        //Assert
        Assert.AreEqual(car.Make, make);
        Assert.AreEqual(car.Model, model);
        Assert.AreEqual(car.FuelConsumption, fuelConsumption);
        Assert.AreEqual(car.FuelCapacity, fuelCapacity);
        Assert.AreEqual(car.FuelAmount, 0);
    }

    [Test]
    [TestCase("")]
    [TestCase(null)]
    public void CarConstructorShouldThrowExceptionIfMakeIsNullOrEmpty(string make)
    {
        Assert.Throws<ArgumentException>(() => new Car(make, "model", 10, 10));
    }

    [Test]
    [TestCase("")]
    [TestCase(null)]
    public void CarConstructorShouldThrowExceptionIfModelIsNullOrEmpty(string model)
    {
        Assert.Throws<ArgumentException>(() => new Car("make", model, 10, 10));
    }

    [Test]
    [TestCase(-1)]
    [TestCase(0)]
    public void CarConstructorShouldThrowExceptionIffuelConsumptionIsBelowOrEqualToZero(double fuelConsumption)
    {
        Assert.Throws<ArgumentException>(() => new Car("make", "model", fuelConsumption, 10));
    }

    [TestCase(-1)]
    [TestCase(0)]
    public void CarConstructorShouldThrowExceptionIffuelCapacitysBelowOrEqualToZero(double fuelCapacity)
    {
        Assert.Throws<ArgumentException>(() => new Car("make", "model", 10, fuelCapacity));
    }

    [Test]
    [TestCase("Bmw", "320", 20, 200, 0)]
    [TestCase("Bmw", "320", 20, 200, -1)]
    public void RefuelShouldExceptionWhenPassedValueIsBelowOrEqualToZero(string make, string model, double fuelConsumption, double fuelCapacity, double refuel)
    {
        //Arrange
        Car car = new Car(make: make, model: model, fuelConsumption: fuelConsumption, fuelCapacity: fuelCapacity);

        //Assert
        Assert.Throws<ArgumentException>(() => car.Refuel(refuel));
    }

    [Test]
    [TestCase("Bmw", "320", 10, 100, 50, 50)]
    [TestCase("Bmw", "320", 20, 200, 350, 200)]
    public void RefuelShouldWorkAsExpected(string make, string model, double fuelConsumption, double fuelCapacity, double refuel, double expectedResult)
    {
        //Arrange
        Car car = new Car(make: make, model: model, fuelConsumption: fuelConsumption, fuelCapacity: fuelCapacity);

        //Act
        car.Refuel(refuel);

        //Assert
        Assert.AreEqual(car.FuelAmount, expectedResult);
    }

    [Test]
    [TestCase("Bmw", "320", 20, 100, 50, 10000)]
    [TestCase("Bmw", "320", 100, 15, 30, 201)]
    public void DriveShouldThrowExceptionIfFuelAmountIsNotEnought(string make, string model, double fuelConsumption, double fuelCapacity, double refuel, double distance)
    {
        //Arrange
        Car car = new Car(make: make, model: model, fuelConsumption: fuelConsumption, fuelCapacity: fuelCapacity);

        //Act
        car.Refuel(refuel);

        //Assert
        Assert.Throws<InvalidOperationException>(() => car.Drive(distance));
    }

    [Test]
    [TestCase("Bmw", "320", 10, 100, 100, 50, 95)]
    [TestCase("Bmw", "320", 10, 100, 100, 1000, 0)]
    public void DriveShouldReduceFuelBasedOnDriveKm(string make, string model, double fuelConsumption, double fuelCapacity, double refuel, double distance, double expectedValue)
    {
        //Arrange
        Car car = new Car(make: make, model: model, fuelConsumption: fuelConsumption, fuelCapacity: fuelCapacity);

        //Act
        car.Refuel(refuel);
        car.Drive(distance);

        //Assert
        Assert.AreEqual(expectedValue, car.FuelAmount);
    }
}


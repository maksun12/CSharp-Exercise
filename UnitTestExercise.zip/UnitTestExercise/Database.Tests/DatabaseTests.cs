using NUnit.Framework;
using System.Linq;
using System;

public class DatabaseTests
{
    [SetUp]
    public void Setup()
    {
    }

    [Test]
    public void ConstructorShouldBeInitializeWith16Elements()
    {
        int[] numbers = Enumerable.Range(1, 16).ToArray();
        Database.Database database = new Database.Database(numbers);
        var expectedResult = 16;
        var actualResult = database.Count;
        Assert.AreEqual(actualResult, expectedResult);
    }

    [Test]
    public void AddOperationShouldAddAnElementAtTheNextFreeCell()
    {
        //Arange
        int[] numbers = Enumerable.Range(1, 10).ToArray();
        Database.Database database = new Database.Database(numbers);

        //Act
        database.Add(5);
        var allElement = database.Fetch();

        //Assert
        var expectedResult = 5;
        var actualResult = allElement[10];
        Assert.AreEqual(actualResult, expectedResult);
    }

    [Test]
    public void AddOperationShouldThrowExceptionIfElementAreAbove16()
    {
        //Arange
        int[] numbers = Enumerable.Range(1, 16).ToArray();
        Database.Database database = new Database.Database(numbers);

        //Assert
        Assert.Throws<InvalidOperationException>(() => database.Add(10));
    }

    [Test]
    public void RemoveOperationShouldSupportOnlyRemovingAnElementAtTheLastIndex()
    {
        //Arange
        int[] numbers = Enumerable.Range(1, 10).ToArray();
        Database.Database database = new Database.Database(numbers);

        //Act
        database.Remove();
        var allElement = database.Fetch();

        //Assert
        var expectedResult = 9;
        var actualResult = database.Count;
        Assert.AreEqual(actualResult, expectedResult);
    }

    [Test]
    public void RemoveOperationShouldThrowExceptionIfDatabaseIsEmpty()
    {
        //Arange
        Database.Database database = new Database.Database();

        //Assert
        Assert.Throws<InvalidOperationException>(() => database.Remove());
    }

    [Test]
    public void FetchShouldReturnAllElement()
    {
        //Arange
        int[] numbers = Enumerable.Range(1, 5).ToArray();
        Database.Database database = new Database.Database(numbers);

        //Act
        var allElement = database.Fetch();

        //Assert
        int[] expectedResult = { 1, 2, 3, 4, 5 };
        var actualResult = allElement;
        Assert.AreEqual(actualResult, expectedResult);
    }
}

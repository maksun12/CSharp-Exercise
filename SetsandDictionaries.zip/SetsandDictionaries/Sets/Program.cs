﻿using System;
using System.Collections.Generic;

namespace Sets
{
    class Program
    {
        static void Main(string[] args)
        {
            HashSet<int> nums = new HashSet<int>();

            nums.Add(5);
            nums.Add(6);
            nums.Add(7);
            nums.Add(1);

            foreach (var item in nums)
            {
                Console.WriteLine(item);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace RecordUniqueNames
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = Console.ReadLine().Split(" ").Select(int.Parse).ToArray();
            int a = n[0];
            int b = n[1];

            HashSet<int> firstNumbers = new HashSet<int>();
            HashSet<int> secondNumbers = new HashSet<int>();

        }
    }
}

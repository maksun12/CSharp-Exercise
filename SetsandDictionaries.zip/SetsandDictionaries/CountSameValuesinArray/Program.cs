﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CountSameValuesinArray
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] nums = Console.ReadLine().Split(" ").Select(double.Parse).ToArray();
            
            Dictionary<double, int> times = new Dictionary<double, int>();

            for (int i = 0; i < nums.Length; i++)
            {
                if (!times.ContainsKey(nums[i]))
                {
                    times.Add(nums[i], 0);
                }
                times[nums[i]]++;
            }
            foreach (var item in times)
            {
                Console.WriteLine($"{times.Keys} - {times.Values} times");

            }

        }
    }
}

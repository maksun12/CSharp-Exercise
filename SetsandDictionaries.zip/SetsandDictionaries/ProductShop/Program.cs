﻿using System;
using System.Collections.Generic;

namespace ProductShop
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, Dictionary<string, decimal>> shops = new Dictionary<string, Dictionary<string, decimal>>();

            string input = Console.ReadLine();

            while (input!= "Revision")
            {
                var splitted = input.Split(", ");
                var shop = splitted[0];
                var product = splitted[1];
                var price = decimal.Parse(splitted[2]);

            }
            foreach (var item in shops)
            {
                Console.WriteLine($"{shop.Key}");
            }            
        }
        
    }
}

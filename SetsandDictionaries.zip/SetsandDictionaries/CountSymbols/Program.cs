﻿using System;
using System.Collections.Generic;

namespace CountSymbols
{
    class Program
    {
        static void Main(string[] args)
        {

            SortedDictionary<char, int> occurences = new SortedDictionary<char, int>();
            var input = Console.ReadLine();

            for (int i = 0; i < input.Length; i++)
            {
                char currentChar = input[i];
                if (!occurences.ContainsKey(currentChar))
                {
                    occurences.Add(currentChar, 0);
                }
                occurences[currentChar]++;
            }
            foreach (var item in occurences)
            {
                Console.WriteLine($"{item.Key}: {item.Value} time/s");
            }
        }
    }
}

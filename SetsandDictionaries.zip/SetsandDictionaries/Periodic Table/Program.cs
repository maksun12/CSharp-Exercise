﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Periodic_Table
{
    class Program
    {
        static void Main(string[] args)
        {
            
            HashSet<string> unique = new HashSet<string>();    
            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                var input = Console.ReadLine().Split(" ").ToArray();

                foreach (var item in input)
                {

                    unique.Add(item);
                    
                }
               

            }
            var sorted = unique.OrderBy(x => x);
            Console.WriteLine(string.Join(" ",sorted));
        }
    }
}

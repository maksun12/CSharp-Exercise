﻿using System;
using System.Collections.Generic;

namespace CitiesbyContinensandCountry
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, Dictionary<string, string>> continents = new Dictionary<string, Dictionary<string, string>>();
            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {

            }
        }
    }
}

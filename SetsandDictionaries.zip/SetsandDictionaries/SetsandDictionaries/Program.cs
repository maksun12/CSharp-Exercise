﻿using System;
using System.Collections.Generic;

namespace SetsandDictionaries
{
    class Program
    {
        static void Main(string[] args)
        {
            SortedDictionary<string, int> grades = new SortedDictionary<string, int>();

            grades.Add("s",1);

                foreach (var item in grades)
            {
                Console.WriteLine($" {grades.Keys} -> {grades.Values}");
            }
        }
    }
}

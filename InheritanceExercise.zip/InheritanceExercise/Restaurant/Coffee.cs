﻿namespace Restaurant
{
    public class Coffee : HotBeverage
    {
        public double Caffeine { get; set; }
        private const double CoffeeMilliliters = 50;
        private const decimal CoffeePrice = 3.50M;
        public Coffee(string name, double caffeine) : base(name, CoffeePrice, CoffeeMilliliters)
        {
            Caffeine = caffeine;

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using System.Xml.Serialization;
using TeisterMask.Data.Models.Enums;

namespace TeisterMask.DataProcessor.ImportDto
{
    [XmlType("Project")]
    public class ProjcectInputModel
    {
        [Required]
        [StringLength(40, MinimumLength = 2)]
        [XmlElement("Name")]
        public string Name { get; set; }
       
        [XmlElement("OpenDate")]
        public string OpenDate { get; set; }
       
        [XmlElement("DueDate")]
        public string DueDate { get; set; }
       
        [XmlElement("Tasks")]
        public TaskInput[] Tasks { get; set; }



    }
    [XmlType("Task")]
    public class TaskInput
    {
        [Required]
        [StringLength(40, MinimumLength = 2)]
        [XmlAttribute("Name")]
        public string Name { get; set; }
        
        [XmlAttribute("OpenDate")]
        public string OpenDate { get; set; }
       
        [XmlAttribute("DueDate")]
        public string DueDate { get; set; }
        
        [EnumDataType(typeof(ExecutionType))]
        [XmlAttribute("ExecutionType")]
        public string ExecutionType { get; set; }
       
        [EnumDataType(typeof(LabelType))]
        [XmlAttribute("LabelType")]
        public string LabelType { get; set; }
    }
}


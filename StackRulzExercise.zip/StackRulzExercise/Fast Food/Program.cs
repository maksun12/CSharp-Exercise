﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace Fast_Food
{
    class Program
    {
        static void Main(string[] args)
        {
            int input = int.Parse(Console.ReadLine());
            var numbers = Console.ReadLine().Split(" ").Select(int.Parse).ToArray();
            Queue<int> queue = new Queue<int>(numbers);
            Console.WriteLine(queue.Max());

            while (queue.Count>0)
            {
               var food= queue.Peek();
                if (input>=food)
                {
                    input -= food;
                    queue.Dequeue();
                }
                else
                {
                    break;
                }
            }
            if (true)
            {

            }
            if (queue.Count>0)
            {
                Console.WriteLine($"Orders left: " + string.Join(" ", queue));
            }
            else
            {
                Console.WriteLine("Orders complete");
            }

        }
    }
}
